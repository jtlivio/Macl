using System;
using System.Runtime.InteropServices;
using System.Drawing;

namespace MACL
{
    [Guid("352CB030-204E-4cb3-BFAB-73DA19CD63EC")]
    [InterfaceType(ComInterfaceType.InterfaceIsIDispatch)]
    public interface Im3Clipboard
    {
        [DispId(1)]
        bool SendTextToClipboard(string MyText, Int16 MyFormat);

        [DispId(2)]
        string GetTextFromClipboard(Int16 MyFormat);

        [DispId(3)]
        bool SendImageToClipboard(Image MyImage);

        [DispId(4)]
        Image GetImageFromClipboard();        
    }
}
