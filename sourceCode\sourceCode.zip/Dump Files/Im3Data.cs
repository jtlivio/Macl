using System;
using System.Runtime.InteropServices;

namespace MACL
{
    [Guid("B35BA82A-3758-49d3-BA81-936F8816FB92")]
    [InterfaceType(ComInterfaceType.InterfaceIsIDispatch)]
    public interface Im3Data
    {
        [DispId(1)]
        ADODB.Recordset ReturnRecordset(String MyConnectionString, String MyTableOrSQL,
                                        ADODB.CursorTypeEnum MyCursorType);

        [DispId(2)]
        ADODB.Recordset ReturnRecordsetFromFile(String MyConnectionString, String MyTextFilePath,
                                        ADODB.CursorTypeEnum MyCursorType);

        [DispId(3)]
        bool ExecuteSql(String MyConnectionString, String MySQLStatement);

        [DispId(4)]
        bool ExecuteSqlFromFile(String MyConnectionString, String MyTextFilePath);

        [DispId(5)]
        bool ExecuteProcedure(String MyConnectionString, String MyProcedureName);

        [DispId(6)]
        bool ExecuteProcedureFromFile(String MyConnectionString, String MyTextFilePath);
    }
}
