﻿using System;
using System.IO;
using System.Runtime.InteropServices;
using Access = Microsoft.Office.Interop.Access;
using Office = Microsoft.Office.Core;

namespace MACL
{
    [ComVisible(true)]
    [Guid("C598F825-20A4-43aa-8B92-A003A7324DBD")]
    [ClassInterface(ClassInterfaceType.None)]
    [ProgId("m3DatabaseUtilities")]
    public class m3DatabaseUtilities : Im3DatabaseUtilities
    {   
        public bool BackupCurrentDatabase(string MyDestinationpathAndFile)
        {   
            Access.Application oAccess = ((Access.Application)
                (Marshal.GetActiveObject("Access.Application")));
            try
            {
                File.Copy(oAccess.CurrentProject.FullName, MyDestinationpathAndFile);
                return true;                
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                Marshal.ReleaseComObject(oAccess);
            }
        }

        public bool CompactRepairExternal(string MySourceDatabase, 
            string MyDestinationDump, bool GenerateLogFile)
        {
            Access.Application oAccess = ((Access.Application)
                (Marshal.GetActiveObject("Access.Application")));
            try
            {
                oAccess.Application.CompactRepair(MySourceDatabase, MyDestinationDump, GenerateLogFile);
                return true;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                Marshal.ReleaseComObject(oAccess);
            }
        }

        public string VBAReferencesCount()
        {
            Access.Application oAccess = ((Access.Application)
                (Marshal.GetActiveObject("Access.Application")));
            try
            {
                return oAccess.References.Count.ToString();                
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                Marshal.ReleaseComObject(oAccess);
            }
        }

        public bool VBAAddReferenceFromFile(string MyFilePath)
        {
            Access.Application oAccess = ((Access.Application)
                (Marshal.GetActiveObject("Access.Application")));
            try
            {
                oAccess.References.AddFromFile(MyFilePath);
                return true;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                Marshal.ReleaseComObject(oAccess);
            }
        }

        public bool VBAAddReferenceFromGUID(string MyGUID, int Major, int Minor)
        {
            Access.Application oAccess = ((Access.Application)
                (Marshal.GetActiveObject("Access.Application")));
            try
            {
                oAccess.References.AddFromGuid(MyGUID, Major, Minor);                 
                return true;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                Marshal.ReleaseComObject(oAccess);
            }
        }

        public bool ConvertCurrentDatabase(string MyDestinationPathAndFile, int ToVersion)
        {
            Access.Application oAccess = ((Access.Application)
                (Marshal.GetActiveObject("Access.Application")));
            try
            {
                if (ToVersion == 2)
                {
                    oAccess.ConvertAccessProject(oAccess.CurrentProject.FullName, 
                        MyDestinationPathAndFile, Access.AcFileFormat.acFileFormatAccess2);                     
                }
                else if (ToVersion == 95)
                {
                    oAccess.ConvertAccessProject(oAccess.CurrentProject.FullName, 
                        MyDestinationPathAndFile, Access.AcFileFormat.acFileFormatAccess95);                    
                }
                else if (ToVersion == 97)
                {
                    oAccess.ConvertAccessProject(oAccess.CurrentProject.FullName, 
                        MyDestinationPathAndFile, Access.AcFileFormat.acFileFormatAccess97);
                }
                else if (ToVersion == 2000)
                {
                    oAccess.ConvertAccessProject(oAccess.CurrentProject.FullName, 
                        MyDestinationPathAndFile, Access.AcFileFormat.acFileFormatAccess2000);
                }
                else if (ToVersion == 2002)
                {
                    oAccess.ConvertAccessProject(oAccess.CurrentProject.FullName, 
                        MyDestinationPathAndFile, Access.AcFileFormat.acFileFormatAccess2002);
                }
                else if (ToVersion == 2007)
                {
                    oAccess.ConvertAccessProject(oAccess.CurrentProject.FullName, 
                        MyDestinationPathAndFile, Access.AcFileFormat.acFileFormatAccess2007);
                }               
                return true;            
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                Marshal.ReleaseComObject(oAccess);
            }
        }
    }
}
