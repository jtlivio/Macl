using System;
using System.Diagnostics;
using System.Runtime.InteropServices;

namespace MACL
{   
    [ComVisible(true)]
    [Guid("D3B377F1-58DD-4e9a-8E38-510E440FFF9C")]
    [ClassInterface(ClassInterfaceType.None)]
    [ProgId("m3Windows")]
    public class m3Windows : Im3Windows
    {
        protected PerformanceCounter cpuCounter; 
        protected PerformanceCounter ramCounter; 

        public String GetOSFullName()
        {
            try
            {                
                // Get OperatingSystem information from the system namespace.
                System.OperatingSystem osInfo = System.Environment.OSVersion;

                // Determine the platform.
                switch (osInfo.Platform)
                {
                    // Platform is Windows 95, Windows 98, 
                    // Windows 98 Second Edition, or Windows Me.
                    case System.PlatformID.Win32Windows:

                        switch (osInfo.Version.Minor)
                        {
                            case 0:
                                return "Windows 95";
                            case 10:
                                if (osInfo.Version.Revision.ToString() == "2222A")
                                    return "Windows 98 Second Edition";
                                else
                                    return "Windows 98";
                            case 90:
                                return "Windows Me";
                        }
                        break;

                    // Platform is Windows NT 3.51, Windows NT 4.0, Windows 2000,
                    // or Windows XP.
                    case System.PlatformID.Win32NT:

                        switch (osInfo.Version.Major)
                        {
                            case 3:
                                return "Windows NT 3.51";
                            case 4:
                                return "Windows NT 4.0";
                            case 5:
                                if (osInfo.Version.Minor == 0)
                                    return "Windows 2000";
                                else
                                    return "Windows XP";
                            case 6:
                                return "Windows Vista";
                            case 7:
                                return "Windows 7";
                        } break;
                }
                return "TESTE";
            }
            catch (Exception)
            {
                throw;                
            }
        }

        public String GetOSServicePack()
        {
            try
            {
                // Get OperatingSystem information from the system namespace.
                System.OperatingSystem osInfo = System.Environment.OSVersion;
                return osInfo.ServicePack.ToString();
            }
            catch (Exception)
            {
                throw;                
            }
        }

        public String GetOSVersionString()
        {
            try
            {
                // Get OperatingSystem information from the system namespace.
                System.OperatingSystem osInfo = System.Environment.OSVersion;
                return osInfo.VersionString;
            }
            catch (Exception)
            {
                throw;                
            }
        }

        public String GetOSPlatform()
        {
            try
            {
                // Get OperatingSystem information from the system namespace.
                System.OperatingSystem osInfo = System.Environment.OSVersion;
                return Convert.ToString(osInfo.Platform);
            }
            catch (Exception)
            {
                throw;                
            }
        }

        public String GetMachineDomainName()
        {
            try
            {
                // Get OperatingSystem information from the system namespace.            
                return Convert.ToString(System.Environment.UserDomainName);
            }
            catch (Exception)
            {
                throw;                
            }
        }

        public String GetMachineName()
        {
            try
            {
                // Get OperatingSystem information from the system namespace.            
                return Convert.ToString(System.Environment.MachineName);
            }
            catch (Exception)
            {
                throw;                
            }
        }

        public String GetMachineProcessorCount()
        {
            try
            {
                // Get OperatingSystem information from the system namespace.            
                return Convert.ToString(System.Environment.ProcessorCount);
            }
            catch (Exception)
            {
                throw;                
            }
        }

         public float GetAvailableRAMInMB()
        {
            try
            {
                ramCounter = new PerformanceCounter("Memory", "Available MBytes");
                return ramCounter.NextValue();
            }
            catch (Exception)
            {
                throw;                
            }
        }

        public bool IsInternetAvailable()
        {
            try
            {
                using (System.Net.Sockets.TcpClient clnt = 
                    new System.Net.Sockets.TcpClient("www.microsoft.com", 80))
                {                    
                    clnt.Close();
                }
                return true;
            }
            catch (Exception)
            {
                throw;
            } 
        }
    }
}
