using System;
using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace MACL
{
    [ComVisible(true)]
    [Guid("7F700723-B4A0-4136-9354-FC7A3B8AF4C4")]
    [ClassInterface(ClassInterfaceType.None)]
    [ProgId("m3Keyboard")]
    public class m3Keyboard : Im3Keyboard
    {
        public bool IsCapsLockOn()
        {
            try
            {
                if (Control.IsKeyLocked(Keys.CapsLock))
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        public bool IsNumLockOn()
        {
            try
            {
                if (Control.IsKeyLocked(Keys.NumLock))
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception)
            {
                throw;                
            }
        }

        public bool IsScrollLockOn()
        {
            try
            {
                if (Control.IsKeyLocked(Keys.Scroll))
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}
