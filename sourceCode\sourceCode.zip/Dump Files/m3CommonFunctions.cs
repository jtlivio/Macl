using System;
using System.Runtime.InteropServices;
using Access = Microsoft.Office.Interop.Access;


namespace MACL
{
    [ComVisible(true)]
    [Guid("82382232-F1D7-4048-A1E0-F2879BCA0610")]
    [ClassInterface(ClassInterfaceType.None)]
    [ProgId("m3CommonFunctions")]
    public class m3CommonFunctions : Im3CommonFunctions
    {
        public string ExtractAge(DateTime BirthDate, Int16 MyOutputFormat)
        {
            DateTime NowDate = DateTime.Today;
            int years = NowDate.Year - BirthDate.Year;
            int months = 0;
            int days = 0;
            // Check if the last year was a full year. 
            if (NowDate < BirthDate.AddYears(years) && years != 0)
            {
                --years;
            }
            BirthDate = BirthDate.AddYears(years);
            // Now we know start <= end and the diff between them
            // is < 1 year. 
            if (BirthDate.Year == NowDate.Year)
            {
                months = NowDate.Month - BirthDate.Month;
            }
            else
            {
                months = (12 - BirthDate.Month) + NowDate.Month;
            }
            // Check if the last month was a full month.
            if (NowDate < BirthDate.AddMonths(months) && months != 0)
            {
                --months;
            }
            BirthDate = BirthDate.AddMonths(months);
            // Now we know that start < end and is within 1 month
            // of each other. 
            days = (NowDate - BirthDate).Days;
            if (MyOutputFormat == 0)
            {
                return Convert.ToString(years);
            }
            else if (MyOutputFormat == 1)
            {
                return years + " years " + months + " months " + days + " days"; 
            }
            else if (MyOutputFormat == 2)
            {
                return years + "." + months + "." + days;
            }
            else if (MyOutputFormat == 3)
            {
                return years + "-" + months + "-" + days;
            }
            else if (MyOutputFormat == 4)
            {
                return Convert.ToString(years) + Convert.ToString(months) + Convert.ToString(days);
            }
            else if (MyOutputFormat == 5)
            {
                return Convert.ToString(years);
            }
            else if (MyOutputFormat == 6)
            {
                return Convert.ToString(months);
            }
            else if (MyOutputFormat == 7)
            {
                return Convert.ToString(days);
            }
            return "Output Type Error!";
        }
    }
}
