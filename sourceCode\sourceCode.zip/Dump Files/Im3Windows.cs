using System;
using System.Runtime.InteropServices;

namespace MACL
{
    [Guid("D1170473-31EF-4409-A6C6-6616E65483F0")]
    [InterfaceType(ComInterfaceType.InterfaceIsIDispatch)]
    public interface Im3Windows
    {
        [DispId(1)]        
        string GetOSFullName();

        [DispId(2)]        
        string GetOSServicePack();

        [DispId(3)]
        string GetOSVersionString();

        [DispId(4)]
        string GetOSPlatform();

        [DispId(5)]
        string GetMachineDomainName();

        [DispId(6)]
        string GetMachineName();

        [DispId(7)]
        string GetMachineProcessorCount();

        [DispId(8)]
        float GetAvailableRAMInMB();

        [DispId(9)]
        bool IsInternetAvailable();
    }
}
