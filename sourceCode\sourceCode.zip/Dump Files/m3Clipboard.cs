using System;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using System.Drawing;

namespace MACL
{   
    [ComVisible(true)]
    [Guid("0ECAA04B-9C55-427d-8EE8-4488B1141708")]
    [ClassInterface(ClassInterfaceType.None)]
    [ProgId("m3Clipboard")]
    public class m3Clipboard : Im3Clipboard
    {
        public bool SendTextToClipboard(string MyText, Int16 MyFormat)
        {
            try
            {
                Clipboard.Clear();

                if (MyFormat == 0)
                {
                    Clipboard.SetText(MyText,TextDataFormat.CommaSeparatedValue);
                    return true;                    
                }
                else if ((MyFormat == 1))
                {
                    Clipboard.SetText(MyText, TextDataFormat.Html);
                    return true;
                }
                else if ((MyFormat == 2))
                {
                    Clipboard.SetText(MyText, TextDataFormat.Rtf);
                    return true;
                }
                else if ((MyFormat == 3))
                {
                    Clipboard.SetText(MyText, TextDataFormat.Text);
                    return true;
                }
                else if ((MyFormat == 4))
                {
                    Clipboard.SetText(MyText, TextDataFormat.UnicodeText);
                    return true;
                }
                return true;
            }                
            catch (Exception)
            {
                throw;
            }            
        }

        public string GetTextFromClipboard(Int16 MyFormat)
        {
            string vText;
            try
            {
                if (MyFormat == 0)
                {
                    vText = Clipboard.GetText(TextDataFormat.CommaSeparatedValue);
                    return vText;
                }
                else if ((MyFormat == 1))
                {
                    vText = Clipboard.GetText(TextDataFormat.Html);
                    return vText;
                }
                else if ((MyFormat == 2))
                {
                    vText = Clipboard.GetText(TextDataFormat.Rtf);
                    return vText;
                }
                else if ((MyFormat == 3))
                {
                    vText = Clipboard.GetText(TextDataFormat.Text);
                    return vText;
                }
                else if ((MyFormat == 4))
                {
                    vText = Clipboard.GetText(TextDataFormat.UnicodeText);
                    return vText;
                }
                return "Error Pasting!";
            }
            catch (Exception)
            {
                throw;
            }
        }

        public bool SendImageToClipboard(Image MyImage)
        {
            //BMP, ICO, CUR, RLE, WMF, EMF, GIF, JPG 
            try
            {
                Clipboard.Clear();

                Clipboard.SetImage(MyImage);                
                return true;
            }
            catch (Exception)
            {
            	throw;
            }            
        }

        public Image GetImageFromClipboard()
        {
            //BMP, ICO, CUR, RLE, WMF, EMF, GIF, JPG 
            Image vImage;
            try
            {
               vImage = Clipboard.GetImage();
                return vImage;
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}
