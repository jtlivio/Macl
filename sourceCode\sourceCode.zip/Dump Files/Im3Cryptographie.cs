using System;
using System.Runtime.InteropServices;

namespace MACL
{
    [Guid("EC98CFB2-AD72-48ee-8B55-4E993CF62B3C")]
    [InterfaceType(ComInterfaceType.InterfaceIsIDispatch)]
    public interface Im3Cryptographie
    {
        [DispId(1)]
        string EncryptString(string StringToEncrypt, string MyKey);

        [DispId(2)]
        string DecryptString(string StringToDecrypt, string MyKey);
    }
}
