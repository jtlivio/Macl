﻿using System;
using System.Runtime.InteropServices;

namespace MACL
{
    [Guid("5264889C-44E3-4d32-B99C-E1F6C8167138")]
    [InterfaceType(ComInterfaceType.InterfaceIsIDispatch)]
    public interface Im3DatabaseUtilities
    {
        [DispId(1)]
        bool BackupCurrentDatabase(string MyDestinationpathAndFile);

        [DispId(2)]
        string VBAReferencesCount();

        [DispId(3)]
        bool VBAAddReferenceFromFile(string MyFilePath);

        [DispId(4)]
        bool VBAAddReferenceFromGUID(string MyGUID, int Major, int Minor);

        [DispId(5)]
        bool ConvertCurrentDatabase(string MyDestinationPathAndFile, int ToVersion);
    }
}
