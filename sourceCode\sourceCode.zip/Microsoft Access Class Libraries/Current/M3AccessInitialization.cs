﻿using System;
using System.Runtime.InteropServices;
using Access = Microsoft.Office.Interop.Access;

namespace Macl
{
    [ComVisible(true)]
    [Guid("E2D5C6F1-1E8D-4f2b-BE76-3194F13ABB62")]
    [ClassInterface(ClassInterfaceType.None)]
    [ProgId("M3AccessInitialization")]
    public class M3AccessInitialization : IM3AccessInitialization
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="hideNavigationPane"></param>
        /// <param name="myUIName"></param>
        /// <param name="myUIXML"></param>
        /// <returns>True/False</returns>
        public bool InitializeDatabase(bool hideNavigationPane, 
            string myUIName, string myUIXML)
        {   
            Access.Application oAccess = ((Access.Application)
                   (Marshal.GetActiveObject("Access.Application")));
            try
            {                   
                oAccess.SetOption("DesignWithData", false);                
                oAccess.SetOption("Perform Name AutoCorrect", false);
                oAccess.SetOption("Track Name AutoCorrect Info", false);
                oAccess.SetOption("Auto Compact", false);                                
                oAccess.SetOption("Confirm Record Changes", false);
                oAccess.SetOption("Confirm Document Deletions", false);
                oAccess.SetOption("Confirm Action Queries", false);

                oAccess.LoadCustomUI(myUIName, myUIXML);

                if (hideNavigationPane == true)
                {
                    oAccess.DoCmd.RunCommand(Access.AcCommand.acCmdWindowHide);
                }                
                return true;                
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                Marshal.ReleaseComObject(oAccess);
            }
        }
    }
}
