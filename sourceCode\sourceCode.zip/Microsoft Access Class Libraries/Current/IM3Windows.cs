using System;
using System.Runtime.InteropServices;

namespace Macl
{
    [Guid("099CAAEF-D55A-4e7f-A8B8-F1F0A51208F7")]
    [InterfaceType(ComInterfaceType.InterfaceIsIDispatch)]
    public interface IM3Windows
    {
        [DispId(1)]        
        string GetOSFullName();

        [DispId(2)]        
        string GetOSServicePack { get; }

        [DispId(3)]
        string GetOSVersionString { get; }

        [DispId(4)]
        string GetOSPlatform { get; }

        [DispId(5)]
        string GetMachineDomainName { get; }

        [DispId(6)]
        string GetMachineName { get; }

        [DispId(7)]
        int GetMachineProcessorCount { get; }

        [DispId(8)]
        float GetAvailableRAMInMB { get; }

        [DispId(9)]
        bool IsInternetAvailable();

        [DispId(10)]
        bool ShutDownWindows(string Mode);
    }
}
