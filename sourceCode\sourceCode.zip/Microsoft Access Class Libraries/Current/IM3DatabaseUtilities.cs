﻿using System;
using System.Runtime.InteropServices;
using Access = Microsoft.Office.Interop.Access;

namespace Macl
{
    [Guid("5264889C-44E3-4d32-B99C-E1F6C8167138")]
    [InterfaceType(ComInterfaceType.InterfaceIsIDispatch)]
    public interface IM3DatabaseUtilities
    {
        [DispId(1)]
        bool BackupCurrentDatabase(string MyDestinationpathAndFile);

        [DispId(2)]
        int VBAReferencesCount { get; }

        [DispId(3)]
        bool VBAAddReferenceFromFile(string MyFilePath);

        [DispId(4)]
        bool VBAAddReferenceFromGUID(string MyGUID, int Major, int Minor);

        [DispId(5)]
        bool ConvertCurrentDatabase(string MyDestinationPathAndFile, int ToVersion);

        [DispId(6)]
        string GenerateGUID();

        [DispId(7)]
        string GetAccessVersion { get; }

        [DispId(8)]
        bool LogAccessError(string MyTable, string ErrNumber, string ErrDescription);

        [DispId(9)]
        bool TablesAreEqual(string MyTableSource, string MyTableToCompare, string MyIndexField);

        [DispId(10)]
        string PlayWAVFile(string myPath);

        [DispId(11)]
        bool ConvertReportToPDF(string myReport, string PDFileName);

        [DispId(12)]
        bool ConvertReportToXPS(string myReport, string XPSFileName);

        [DispId(13)]
        bool ConvertReportToHTML(string myReport, string HTMLFileName);

        [DispId(14)]
        bool ConvertReportToXLSX(string myReport, string XLSXFileName);

        [DispId(15)]
        bool ConvertReportToRTF(string myReport, string RTFFileName);

        [DispId(16)]
        bool ConvertReportToASP(string myReport, string ASPFileName);
    }
}
