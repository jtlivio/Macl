using System;
using System.Data;
using System.Data.OleDb;
using System.IO;
using System.Runtime.InteropServices;
using Access = Microsoft.Office.Interop.Access;

namespace Macl
{   
    [ComVisible(true)]
    [Guid("106CD2EB-BF6A-4069-BBBA-880FE5C9CB6C")]
    [ClassInterface(ClassInterfaceType.None)]
    [ProgId("M3Data")]
    public class M3Data : IM3Data
    {
        public ADODB.Recordset ReturnRecordset(String MyConnectionString, String MyTableOrSQL,
                                               ADODB.CursorTypeEnum MyCursorType)
        {
            ADODB.Connection cnn = new ADODB.Connection();
            ADODB.Recordset rs = new ADODB.Recordset();
            
            try
            {
                cnn.ConnectionString = MyConnectionString;                
                cnn.Open(null, null, null, 0);
                //}                
                rs.Open(MyTableOrSQL, cnn, MyCursorType, ADODB.LockTypeEnum.adLockOptimistic, -1);
                return rs;
            }
            catch (Exception)
            {
                throw;
            }
        }

        public ADODB.Recordset ReturnRecordsetFromFile(String MyConnectionString, String MyTextFilePath,
                                                       ADODB.CursorTypeEnum MyCursorType)
        {
            ADODB.Connection cnn = new ADODB.Connection();
            ADODB.Recordset rs = new ADODB.Recordset();

            try
            {
                using (StreamReader fh = new StreamReader(MyTextFilePath))
                {
                    String MyText;
                    String s;
                    while ((s = fh.ReadLine()) != null)
                        MyText = s;
                    fh.Close();
                    cnn.ConnectionString = MyConnectionString;
                    //if (cnn.State = ConnectionState.Closed)
                    //{
                    cnn.Open(null, null, null, 0);
                    //}                
                    rs.Open(s, cnn, MyCursorType, ADODB.LockTypeEnum.adLockOptimistic, -1);
                }
                return rs;
            }
            catch (Exception)
            {
                throw;
            }
        }

        public bool ExecuteSql(String MyConnectionString, String MySQLStatement)
        {
            using (OleDbConnection cnn = new OleDbConnection(MyConnectionString))
            {
                OleDbCommand cmd = new OleDbCommand();
                try
                {
                    cmd.CommandText = MySQLStatement;
                    cmd.CommandType = CommandType.Text;
                    cmd.Connection = cnn;
                    cnn.Open();
                    cmd.ExecuteNonQuery();
                    cnn.Close();
                    return true;
                }
                catch (Exception)
                {
                    throw;
                }
                finally
                {
                    cnn.Close();
                    cmd.Dispose();
                }
            }
        }

        public bool ExecuteSqlFromFile(String MyConnectionString, String MyTextFilePath)
        {
            using (OleDbConnection sqlConnection = new OleDbConnection(MyConnectionString))
            {
                OleDbCommand cmd = new OleDbCommand();
                try
                {
                    using (StreamReader fh = new StreamReader(MyTextFilePath))
                    {
                        String MyText;
                        string s;
                        while ((s = fh.ReadLine()) != null)
                            MyText = s;
                        fh.Close();
                        cmd.CommandText = s;
                    }
                    cmd.CommandType = CommandType.Text;
                    cmd.Connection = sqlConnection;
                    sqlConnection.Open();
                    cmd.ExecuteNonQuery();
                    sqlConnection.Close();
                    return true;
                }
                catch (Exception)
                {
                    throw;
                }
                finally
                {
                    sqlConnection.Close();
                    cmd.Dispose();
                }
            }
        }

        public bool ExecuteProcedure(String MyConnectionString, String MyProcedureName)
        {
            using (OleDbConnection sqlConnection = new OleDbConnection(MyConnectionString))
            {
                OleDbCommand cmd = new OleDbCommand();
                try
                {
                    cmd.CommandText = String.Format("EXEC {0}", MyProcedureName);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Connection = sqlConnection;
                    sqlConnection.Open();
                    cmd.ExecuteNonQuery();
                    sqlConnection.Close();
                    return true;
                }
                catch (Exception)
                {
                    throw;
                }
                finally
                {
                    sqlConnection.Close();
                    cmd.Dispose();
                }
            }
        }

        public bool ExecuteProcedureFromFile(String MyConnectionString, String MyTextFilePath)
        {
            using (OleDbConnection cnn = new OleDbConnection(MyConnectionString))
            {
                OleDbCommand cmd = new OleDbCommand();
                try
                {                    
                    using (StreamReader fh = new StreamReader(MyTextFilePath))
                    {
                        String MyText;
                        string s;
                        while ((s = fh.ReadLine()) != null)
                            MyText = s;
                        fh.Close();
                        cmd.CommandText = String.Format("EXEC {0}", s);
                    }
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Connection = cnn;
                    cnn.Open();
                    cmd.ExecuteNonQuery();
                    cnn.Close();
                    return true;
                }
                catch (Exception)
                {
                    throw;
                }
                finally
                {
                    cnn.Close();
                    cmd.Dispose();
                }
            }
        }

        public string ConvertFieldToUpper(string MyTable, string MyField)
        {
            Access.Application oAccess = ((Access.Application)
                (Marshal.GetActiveObject("Access.Application")));
            try
            {
                string strSQL;
                strSQL = String.Format("UPDATE {0} SET {1} = UCase([{1}])", MyTable, MyField);

                oAccess.DoCmd.RunSQL(strSQL.ToString(),null);
                return "OK";
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                Marshal.ReleaseComObject(oAccess);
            }
        }

        public string ConvertFieldToLower(string MyTable, string MyField)
        {
            Access.Application oAccess = ((Access.Application)
                (Marshal.GetActiveObject("Access.Application")));
            try
            {
                string strSQL;
                strSQL = String.Format("UPDATE {0} SET {1} = LCase([{1}])", MyTable, MyField);

                oAccess.DoCmd.RunSQL(strSQL.ToString(), null);
                return "OK";
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                Marshal.ReleaseComObject(oAccess);
            }
        }

        public string ConvertFieldToProper(string MyTable, string MyField)
        {
            Access.Application oAccess = ((Access.Application)
                (Marshal.GetActiveObject("Access.Application")));
            try
            {
                string strSQL;
                strSQL = String.Format("UPDATE {0} SET {1} = STRCONV([{1},3])", MyTable, MyField);

                oAccess.DoCmd.RunSQL(strSQL.ToString(), null);
                return "OK";
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                Marshal.ReleaseComObject(oAccess);                
            }
        }        
    }
}
