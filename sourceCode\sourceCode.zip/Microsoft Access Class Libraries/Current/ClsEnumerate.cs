﻿using System;
using System.Windows.Forms;

namespace Macl
{
    internal class ClsEnumerate
    {

        [Flags]
        internal enum acM3ClipBoardFormats
        {
            CommaSeparatedValue = TextDataFormat.CommaSeparatedValue,
            Html = TextDataFormat.Html,
            Rtf = TextDataFormat.Rtf,
            Text = TextDataFormat.Text,
            UnicondText = TextDataFormat.UnicodeText,
        }
    }
}
