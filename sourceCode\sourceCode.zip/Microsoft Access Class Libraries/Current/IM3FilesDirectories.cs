using System;
using System.Runtime.InteropServices;
using IO = System.IO;

namespace Macl
{
    [Guid("8D182035-4711-4377-8431-207939AB1895")]
    [InterfaceType(ComInterfaceType.InterfaceIsIDispatch)]
    public interface IM3FilesDirectories
    {
        [DispId(1)]
        bool CreateFile(String MyFilePath);

        [DispId(2)]
        bool CopyFile(String MySourceFile, String MyDestinationFile, bool OverwiteDestination);

        [DispId(3)]
        bool MoveFile(String MySourceFile, String MyDestinationFile);

        [DispId(4)]
        bool DeteleFile(String MyFilePath);

        [DispId(5)]
        bool CreateDirectory(String MyDirectoryPath);

        [DispId(6)]
        bool CopyDirectory(String MySourceDir, String MyDestinationDir);

        [DispId(7)]
        bool MoveDirectory(String MySourceDir, String MyDestinationDir);

        [DispId(8)]
        bool DeteteDirectory(String MySourceDir);
    }
}
