﻿using System;
using System.Runtime.InteropServices;
namespace Macl
{
    [Guid("E5ED200E-17AB-4b4c-99FF-2FBB6015EC39")]
    [InterfaceType(ComInterfaceType.InterfaceIsIDispatch)]
    public interface IM3AccessInitialization
    {
        bool InitializeDatabase(bool hideNavigationPane,
            string myUIName, string myUIXML);
    }
}
