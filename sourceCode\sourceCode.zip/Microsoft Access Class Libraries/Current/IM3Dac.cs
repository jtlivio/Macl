﻿using System;
using System.Runtime.InteropServices;

namespace Macl
{
    [Guid("7DF4A2AF-0810-4df3-A173-27AC7E47FF5B")]
    [InterfaceType(ComInterfaceType.InterfaceIsIDispatch)]
    public interface IM3Dac
    {
        bool GenerateDACVars(string myTable);
    }
}
