using System;
using System.Runtime.InteropServices;
using IO = System.IO;
using System.IO;

namespace Macl
{
    [ComVisible(true)]
    [Guid("DB1F1213-218B-4be1-86FB-89827B2376DA")]
    [ClassInterface(ClassInterfaceType.None)]
    [ProgId("M3FilesDirectories")]
    public class M3FilesDirectories : IM3FilesDirectories
    {
        public bool CreateFile(String MyFilePath)
        {
            try
            {
                if (IO.File.Exists(MyFilePath))
                {
                    throw new IO.FileNotFoundException(
                        String.Format("File Already Exist!! - {0}", MyFilePath));                    
                }
                else
                {
                    IO.File.Create(MyFilePath);
                    return true;
                }                
            }
            catch (Exception)
            {
                throw;
            }
        }

        public bool CopyFile(String MySourceFile, String MyDestinationFile, bool OverwiteDestination)
        {
            try
            {
                if (!IO.File.Exists(MySourceFile))
                {
                	throw new IO.FileNotFoundException(
                        String.Format("Source File not Found!! - {0}", MySourceFile));
                }
                else
                {
                    if (OverwiteDestination == true)
                    {
                        IO.File.Copy(MySourceFile, MyDestinationFile, true);
                        return true;
                    }
                    else
                    {
                        if (IO.File.Exists(MyDestinationFile))
                        {
                            throw new IO.FileNotFoundException(
                                String.Format("{0} - Already Exist!!", MySourceFile));
                        }
                        else
                        {
                            IO.File.Copy(MySourceFile, MyDestinationFile, false);
                            return true;
                        }
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        public bool MoveFile(String MySourceFile, String MyDestinationFile)
        {
            try
            {
                if (!IO.File.Exists(MySourceFile))
                {
                    throw new IO.FileNotFoundException(
                        String.Format("Source File not Found!! - {0}", MySourceFile));
                }
                else
                {   
                    if (IO.File.Exists(MyDestinationFile))
                    {
                        throw new IO.FileNotFoundException(
                            String.Format("{0} - Already Exist!!", MySourceFile));
                    }
                    else
                    {
                        IO.File.Move(MySourceFile, MyDestinationFile);
                        return true;
                    }
                }                
            }
            catch (Exception)
            {
                throw;
            }
        }

        public bool DeteleFile(String MyFilePath)
        {
            try
            {
                if (!IO.File.Exists(MyFilePath))
                {
                    throw new IO.FileNotFoundException(
                        String.Format("File not Found!! - {0}", MyFilePath));
                }
                else
                {
                    IO.File.Delete(MyFilePath);
                    return true;
                }
            }
            catch (Exception)
            {
                throw;
            }

        }

        public bool CreateDirectory(String MyDirectoryPath)
        {
            try
            {
                if (IO.Directory.Exists(MyDirectoryPath))
                {
                    throw new Exception(
                        String.Format("Directory Already Exist!! - {0}", MyDirectoryPath));
                }
                else
                {
                    IO.Directory.CreateDirectory(MyDirectoryPath);
                    return true;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        public bool CopyDirectory(String MySourceDir, String MyDestinationDir)
        {
            try
            {
                if (copyDirectory(MySourceDir, MyDestinationDir) == true)
                {
                	return true;
                }
                return true;   
            }   
            catch (Exception)
            {
                throw;
            }

        }

        public bool MoveDirectory(String MySourceDir, String MyDestinationDir)
        {
            try
            {
                if (!IO.Directory.Exists(MySourceDir))
                {
                    throw new Exception(
                        String.Format("Source Directory not Found!! - {0}", MySourceDir));
                }
                else
                {
                    IO.Directory.Move(MySourceDir,MyDestinationDir);
                    return true;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        public bool DeteteDirectory(String MySourceDir)
        {
            try
            {
                if (!IO.Directory.Exists(MySourceDir))
                {
                    throw new Exception(
                        String.Format("Directory not Found!! - {0}", MySourceDir));
                }
                else
                {
                    IO.Directory.Delete(MySourceDir,true);
                    return true;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        // Copy directory structure recursively
         private static bool copyDirectory(string Src, string Dst)
        {
            try
            {
                String[] Files;

                if (Dst[Dst.Length - 1] != Path.DirectorySeparatorChar)
                    Dst += Path.DirectorySeparatorChar;
                if (!Directory.Exists(Dst)) Directory.CreateDirectory(Dst);
                Files = Directory.GetFileSystemEntries(Src);

                Array.ForEach(Files, Element =>
                {
                    // Sub directories
                    if (Directory.Exists(Element))
                        copyDirectory(Element, Dst + Path.GetFileName(Element));
                    // Files in directory
                    else
                        File.Copy(Element, Dst + Path.GetFileName(Element), true);
                });
                return true;
            }
            catch (Exception)
            {
                throw;                
            }
        }
    }
}
