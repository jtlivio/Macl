using System;
using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace Macl
{
    [ComVisible(true)]
    [Guid("7F700723-B4A0-4136-9354-FC7A3B8AF4C4")]
    [ClassInterface(ClassInterfaceType.None)]
    [ProgId("M3Keyboard")]
    public class M3Keyboard : IM3Keyboard
    {
        /// <summary>
        /// Detects if CAPS LOCK is ON
        /// 
        /// Dim ObjMACL As New M3Keyboard
        /// If IsCapsLockOn() = True Then
        ///    'CAP is ON
        /// End If
        /// </summary>
        /// <returns>True/False</returns>
        public bool IsCapsLockOn()
        {
            try
            {
                if (Control.IsKeyLocked(Keys.CapsLock))
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        /// <summary>
        /// Detects if NUM LOCK is ON
        /// 
        /// Dim ObjMACL As New M3Keyboard
        /// If IsNumLockOn() = True Then
        ///    'NUM is ON
        /// End If
        /// </summary>
        /// <returns>True/False</returns>
        public bool IsNumLockOn()
        {
            try
            {
                if (Control.IsKeyLocked(Keys.NumLock))
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception)
            {
                throw;                
            }
        }

        /// <summary>
        /// Detects if SCROLL LOCK is ON
        /// 
        /// Dim ObjMACL As New M3Keyboard
        /// If IsScrollLockOn() = True Then
        ///    'SCROLL is ON
        /// End If
        /// </summary>
        /// <returns>True/False</returns>
        public bool IsScrollLockOn()
        {
            try
            {
                if (Control.IsKeyLocked(Keys.Scroll))
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}
