using System;
using System.Diagnostics;
using System.Management;
using System.Runtime.InteropServices;

namespace Macl
{   
    [ComVisible(true)]
    [Guid("9033FC75-CCCB-4011-902A-7D369AD5F1C1")]
    [ClassInterface(ClassInterfaceType.None)]
    //[TypeLibType(TypeLibTypeFlags.FCanCreate)]
    [ProgId("M3Windows")]    
    public class M3Windows : IM3Windows
    {
        /// <summary>
        /// Private OperatingSystem osInfo
        /// </summary>
 
        OperatingSystem osInfo = Environment.OSVersion;

        /// <summary>
        /// Get Operative System name
        /// 
        /// Dim ObjMACL As New M3Windows 
        /// ?GetOSFullName()
        /// 
        /// </summary>
        /// <returns>
        /// String 
        /// "Windows XP"
        /// </returns>
        public String GetOSFullName()
        {
            try
            {
                // Get OperatingSystem information from the system namespace.
                OperatingSystem osInfo = Environment.OSVersion;

                // Determine the platform.
                switch (osInfo.Platform)
                {
                    // Platform is Windows 95, Windows 98, 
                    // Windows 98 Second Edition, or Windows Me.
                    case PlatformID.Win32Windows:

                        switch (osInfo.Version.Minor)
                        {
                            case 0:
                                return "Windows 95";
                            case 10:
                                if (osInfo.Version.Revision.ToString() == "2222A")
                                    return "Windows 98 Second Edition";
                                else
                                    return "Windows 98";
                            case 90:
                                return "Windows Me";
                        }
                        break;

                    // Platform is Windows NT 3.51, Windows NT 4.0, Windows 2000,
                    // or Windows XP.
                    case PlatformID.Win32NT:

                        switch (osInfo.Version.Major)
                        {
                            case 3:
                                return "Windows NT 3.51";
                            case 4:
                                return "Windows NT 4.0";
                            case 5:
                                if (osInfo.Version.Minor == 0)
                                    return "Windows 2000";
                                else
                                    return "Windows XP";
                            case 6:
                                return "Windows Vista";
                            case 7:
                                return "Windows 7";
                        } break;
                }
                return "TESTE";
            }
            catch (Exception)
            {
                throw;
            }
        }

        /// <summary>
        /// Get Operative System Service Pack
        /// 
        /// Dim ObjMACL As New M3Windows 
        /// ?GetOSServicePack
        /// Return: "Service Pack 3"
        /// </summary>
        public string GetOSServicePack
        {
            get { return osInfo.ServicePack; }
        }

        /// <summary>
        /// Get Operative System Version
        /// 
        /// Dim ObjMACL As New M3Windows 
        /// ?GetOSVersionString
        /// 
        /// Return: Name, Version, Service Pack
        /// </summary>
        public string GetOSVersionString
        {
            get {  return osInfo.VersionString; }
        }

        /// <summary>
        /// Get Operative System Platform
        /// 
        /// Dim ObjMACL As New M3Windows 
        /// ?GetOSPlatform
        /// 
        /// Return: "Win32NT"
        /// </summary>
        public string GetOSPlatform
        {
            get {  return osInfo.Platform.ToString(); }        
        }

        /// <summary>
        /// Get Operative System Domain Name
        /// 
        /// Dim ObjMACL As New M3Windows 
        /// ?GetMachineDomainName
        /// 
        /// Return: "CONTOSO"
        /// </summary>
        public String GetMachineDomainName
        {
            get { return Environment.UserDomainName; }                    
        }

        /// <summary>
        /// Get PC Name
        /// 
        /// Dim ObjMACL As New M3Windows 
        /// ?GetMachineName
        /// 
        /// Return: "CONTOSO_PC"
        /// </summary>
        public String GetMachineName
        {
            get { return Environment.MachineName; }                               
        }

        /// <summary>
        /// Get PC Processors Count
        /// 
        /// Dim ObjMACL As New M3Windows 
        /// ?GetMachineProcessorCount
        /// 
        /// Return: 2
        /// </summary>
        public int GetMachineProcessorCount
        {
            get { return Environment.ProcessorCount; }                               
        }

        /// <summary>
        /// Get Available RAM in MB
        /// 
        /// Dim ObjMACL As New M3Windows 
        /// ?GetAvailableRAMInMB
        /// 
        /// Return: 800
        /// </summary>
        public float GetAvailableRAMInMB
        {
            get
            {
                using (PerformanceCounter ramCounter = new PerformanceCounter("Memory", "Available MBytes") { })
                {
                    return ramCounter.NextValue();
                }

            }
        }

        /// <summary>
        /// Get internate state by pinging www.microsoft.com on port 80
        /// 
        /// Dim ObjMACL As New M3Windows 
        /// If IsInternetAvailable() = True Then
        ///    MsgBox "Net is On"
        /// End If
        /// 
        /// Return: True/False
        /// </summary>
        public bool IsInternetAvailable()
        {
            try
            {
                using (System.Net.Sockets.TcpClient clnt = 
                    new System.Net.Sockets.TcpClient("www.microsoft.com", 80))
                {   
                    clnt.Close();
                }
                return true;
            }
            catch (Exception)
            {
                throw;
            } 
        }

        /// <summary>
        /// Shutdown or restart Windows
        /// 
        /// Dim ObjMACL As New M3Windows 
        /// If ShutDownWindows() = True Then
        ///    'Do Something or abort
        ///    'to abort use "Shutdown -a"
        /// Else
        ///    'Some Error
        /// End If
        /// 
        /// Return: True/False
        /// </summary>
        public bool ShutDownWindows(string Mode)
        {
            //Mode 1 SHUTDOWN - Mode 2 RESTART
            // You can't shutdown without security privileges
            try
            {
               
                using (ManagementClass mcWin32 = new ManagementClass("Win32_OperatingSystem"))
                {
                    ManagementBaseObject mboShutdown = null;
                    mcWin32.Get();

                    mcWin32.Scope.Options.EnablePrivileges = true;
                    ManagementBaseObject mboShutdownParams = mcWin32.GetMethodParameters("Win32Shutdown");
                    mboShutdownParams["Flags"] = Mode;
                    mboShutdownParams["Reserved"] = "0";
                    foreach (ManagementObject manObj in mcWin32.GetInstances())
                        mboShutdown = manObj.InvokeMethod("Win32Shutdown", mboShutdownParams, null);
                    return true;
                }
            }
            catch (Exception)
            {
                throw;
            }
       }
    }
}
