using System;
using System.Runtime.InteropServices;

namespace Macl
{
    /// <summary>
    /// 
    /// </summary>
    [Guid("4ECAAC7B-711C-4ac0-BBFC-58C4E3E8EE56")]
    [InterfaceType(ComInterfaceType.InterfaceIsIDispatch)]
    public interface IM3CommonFunctions
    {
        [DispId(1)]
        Version GetMACLVersion  { get; }

        [DispId(2)]
        string ExtractAge(DateTime BirthDate, Int16 MyOutputFormat);
    }
}
