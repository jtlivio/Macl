﻿using System;
using ADOX;
using System.Runtime.InteropServices;
using System.Data.OleDb;
using System.Data;

namespace Macl
{

    [ComVisible(true)]
    [Guid("EE971877-39CF-4225-99E4-311C68567CB3")]
    [ClassInterface(ClassInterfaceType.None)]
    [ProgId("M3GenerateDatabases")]
    public class M3GenerateDatabases : IM3GenerateDatabases
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="MyPath"></param>
        /// <returns>True/False</returns>
        public bool GenerateLogDatabase(string myPath)
        {   
            CatalogClass cat = new CatalogClass();
            string strSQL;
            string cs;

            try
            {
                cs = "Provider=Microsoft.Jet.OLEDB.4.0;" +
                     "Data Source=" + myPath + ";" +
                     "Jet OLEDB:Engine Type=5";

                strSQL = "CREATE TABLE Issues (mID AUTOINCREMENT, mUser TEXT(100) NOT NULL " +
                         ", mError TEXT(100) NOT NULL, " +
                         "mDescription TEXT(100) NOT NULL, mDate DATETIME NOT NULL)";

                cat.Create(cs);

                using (OleDbConnection cnn = new OleDbConnection(cs))
                {
                    OleDbCommand cmd = new OleDbCommand();
                    try
                    {
                        cmd.CommandText = strSQL;
                        cmd.CommandType = CommandType.Text;
                        cmd.Connection = cnn;
                        cnn.Open();
                        cmd.ExecuteNonQuery();
                        cnn.Close();
                        return true;
                    }
                    catch (Exception)
                    {
                        throw;
                    }
                    finally
                    {
                        cnn.Close();
                        cmd.Dispose();
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {   
                Marshal.FinalReleaseComObject(cat);
            }
        }
    }
}
