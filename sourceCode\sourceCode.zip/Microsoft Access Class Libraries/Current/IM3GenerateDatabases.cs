﻿using System;
using System.Runtime.InteropServices;

namespace Macl
{
    [Guid("0417F611-E027-4469-83BE-5171F7801A74")]
    [InterfaceType(ComInterfaceType.InterfaceIsIDispatch)]
    public interface IM3GenerateDatabases
    {
        [DispId(1)]
        bool GenerateLogDatabase(string MyPath);
    }
}
