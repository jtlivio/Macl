using System;
using System.Runtime.InteropServices;

namespace Macl
{
    [Guid("142EEBFD-6145-4d2f-AF56-9ACE39CB4CBE")]
    [InterfaceType(ComInterfaceType.InterfaceIsIDispatch)]
    public interface IM3Keyboard
    {
        [DispId(1)]
        bool IsCapsLockOn();

        [DispId(2)]
        bool IsNumLockOn();

        [DispId(3)]
        bool IsScrollLockOn();
    }
}
